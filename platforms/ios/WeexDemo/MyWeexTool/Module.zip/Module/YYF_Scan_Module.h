//
//  YYF_Weex_Module.h
//  WeexDemo
//
//  Created by 科技部iOS on 2018/12/19.
//  Copyright © 2018 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YYF_Base_Module.h"


NS_ASSUME_NONNULL_BEGIN

@interface YYF_Scan_Module : YYF_Base_Module

@end

NS_ASSUME_NONNULL_END
