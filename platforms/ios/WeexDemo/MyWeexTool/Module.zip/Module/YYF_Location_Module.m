//
//  YYF_Location_Module.m
//  WeexDemo
//
//  Created by 科技部iOS on 2018/12/21.
//  Copyright © 2018 taobao. All rights reserved.
//

#import "YYF_Location_Module.h"
#import <CoreLocation/CoreLocation.h>
@interface YYF_Location_Module ()<CLLocationManagerDelegate>

@property (nonatomic,strong) CLLocationManager * locationManager;
@property (nonatomic,strong) CLGeocoder * geocoder;//初始化地理编码器

@end

@implementation YYF_Location_Module

WX_EXPORT_METHOD(@selector(startLocation:));

-(CLGeocoder *)geocoder{
    if (!_geocoder) {
        _geocoder = [[CLGeocoder alloc]init];
    }
    return _geocoder;
}

-(CLLocationManager *)locationManager{
    if (!_locationManager) {
        _locationManager = [[CLLocationManager alloc] init];
        _locationManager.delegate = self;
        _locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    }
    return _locationManager;
}


-(void)startLocation:(WXModuleCallback)callBlock{
    self.callback = callBlock;
    if ([CLLocationManager locationServicesEnabled] &&
        [CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorizedWhenInUse) {
        
        [self.locationManager requestWhenInUseAuthorization];
        
        
    }else{
        [self showAlert:@"App定位权限未打开"
                message:@"请进入系统【设置】>【隐私】>【定位服务】中打开开关，并且允许应用使用定位服务"
             cancelText:@"取消" confirmText:@"去设置" confirmHandle:^{
                 //iOS10
                 [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
             }];
    }
    
}

-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations{
    
    [manager stopUpdatingLocation];
    /*
     1.coordinate : 当前位置的坐标
        latitude : 纬度
        longitude : 经度
     2.altitude : 海拔，高度
     3.horizontalAccuracy : 纬度和经度的精度
     4.verticalAccuracy : 垂直精度(获取不到海拔时为负数)
     5.course : 行进方向(真北)
     6.speed : 以米/秒为单位的速度
     7.description : 位置描述信息
     */
    CLLocation *location = [locations lastObject];
    
    NSMutableDictionary *infoDic = [@{
                                      @"latitude":[NSString stringWithFormat:@"%f",location.coordinate.latitude],
                                      @"longitude":[NSString stringWithFormat:@"%f",location.coordinate.longitude],
                                      @"altitude":[NSString stringWithFormat:@"%f",location.altitude],
                                      @"speed":[NSString stringWithFormat:@"%f",location.speed],
                                      @"description":location.description
                                      } mutableCopy];
    
    [self.geocoder reverseGeocodeLocation:location completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        NSMutableDictionary *addressDic = [NSMutableDictionary dictionary];
        if (error != nil) {
            if (placemarks.count > 0) {
                CLPlacemark *placemark = [placemarks objectAtIndex:0];
                addressDic[@"name"] = placemark.name;
                addressDic[@"thoroughfare"] = placemark.thoroughfare;
                addressDic[@"subThoroughfare"] = placemark.subThoroughfare;
                addressDic[@"locality"] = placemark.locality;
                addressDic[@"subLocality"] = placemark.subLocality;
                addressDic[@"administrativeArea"] = placemark.administrativeArea;
                addressDic[@"subAdministrativeArea"] = placemark.subAdministrativeArea;
                addressDic[@"postalCode"] = placemark.postalCode;
                addressDic[@"ISOcountryCode"] = placemark.ISOcountryCode;
                addressDic[@"country"] = placemark.country;
                addressDic[@"inlandWater"] = placemark.inlandWater;
                addressDic[@"ocean"] = placemark.ocean;
                addressDic[@"areasOfInterest"] = placemark.areasOfInterest;
            }
        }
        infoDic[@"geocoder"] = addressDic;
        self.callback(infoDic);
    }];
}


@end
