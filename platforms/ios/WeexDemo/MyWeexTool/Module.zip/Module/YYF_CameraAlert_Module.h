//
//  CameraAlertModule.h
//  WeexDemo
//
//  Created by hubao on 2018/12/12.
//  Copyright © 2018 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YYF_Base_Module.h"
NS_ASSUME_NONNULL_BEGIN

@interface YYF_CameraAlert_Module : YYF_Base_Module
@end

NS_ASSUME_NONNULL_END
